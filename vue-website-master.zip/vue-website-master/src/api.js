import axios from 'axios';

const API_URL = 'http://127.0.0.1:5000';

export const getUsers = async () => {
    return axios.get(`${API_URL}/users`).then(response => response.data);
};

export const getClasses = async () => {
    return axios.get(`${API_URL}/classes`).then(response => response.data);
};

export const getNotifications = async () => {
    return axios.get(`${API_URL}/notifications`).then(response => response.data);
};
