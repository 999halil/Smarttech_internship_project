import { createApp } from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify'
import { loadFonts } from './plugins/webfontloader'
import "./style/mainStyle.css"
import router from './router'
import 'vuetify/dist/vuetify.min.css';


loadFonts()

createApp(App)
  .use(vuetify)
  .use(router)
  .mount('#app')
