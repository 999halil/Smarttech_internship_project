<template>
  <v-navigation-drawer width="20%" v-model="drawer" temporary right>
    <v-toolbar flat dense>
      <v-btn icon @click="drawer = false">
        <v-icon>mdi-close</v-icon>
      </v-btn>
      <v-toolbar-title>Settings</v-toolbar-title>
    </v-toolbar>

    <v-list dense>
      <!-- User Account Info -->
      <v-list-item>
        <v-list-item-avatar>
          <v-icon size="x-large">mdi-account-circle-outline</v-icon>
        </v-list-item-avatar>
        <v-list-item-content>
          <v-list-item-title>User Name</v-list-item-title>
          <v-list-item-subtitle>Logged in</v-list-item-subtitle>
        </v-list-item-content>
      </v-list-item>
      <v-divider></v-divider>

      <!-- Theme Selection -->
      <v-list-item>
        <v-list-item-content>
          <v-list-item-title>Theme</v-list-item-title>
          <v-list-item-subtitle>Customize your experience with light and dark themes.</v-list-item-subtitle>
        </v-list-item-content>
        <v-list-item-action>
          <v-switch v-model="model" inset color="#274C77" hide-details></v-switch>
        </v-list-item-action>
      </v-list-item>
      <v-divider></v-divider>

      <!-- Language Selection -->
      <v-list-item>
        <v-list-item-content>
          <v-list-item-title>Language</v-list-item-title>
          <v-list-item-subtitle>Customize your experience by choosing the language</v-list-item-subtitle>
        </v-list-item-content>
        <v-list-item-action>
          <v-select v-model="selected" :items="lang" item-text="name" item-value="id" solo></v-select>
        </v-list-item-action>
      </v-list-item>
      <v-divider></v-divider>

      <!-- Additional Settings -->
      <v-list-item to="/settings" link>
        <v-list-item-icon>
          <v-icon>mdi-cog</v-icon>
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title>Settings</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
  </v-navigation-drawer>

  <!-- Main Application Bar -->
  <v-app-bar app color="#274C77" dark>
    <v-toolbar-title>Smartech</v-toolbar-title>
    <v-spacer></v-spacer>
    <v-btn text @click="drawer = !drawer">Open Settings</v-btn>
  </v-app-bar>
</template>

<script>
export default {
  data() {
    return {
      drawer: false,  // Set drawer to false to ensure it starts closed
      selected: 'English',
      lang: [
        { id: 0, name: 'English' },
        { id: 1, name: 'French' },
      ],
      model: false,  // Assuming 'model' is for dark mode toggle
    };
  }
};
</script>

<style scoped>
/* Add custom styles if necessary */
</style>
