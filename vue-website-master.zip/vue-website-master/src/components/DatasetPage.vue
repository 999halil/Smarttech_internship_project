<template>
  <v-container>
    <!-- Header and update timestamp -->
    <v-row justify="space-between">
      <v-col cols="12" md="6">
        <h1>Dataset Management</h1>
        <p>Last updated: {{ lastUpdated }}</p>
      </v-col>
      <v-col cols="12" md="6" class="text-right">
        <v-btn icon color="primary" @click="fetchImages">
          <v-icon>mdi-refresh</v-icon>
        </v-btn>
        <v-btn color="primary" @click="uploadDialog = true">Add to Dataset</v-btn>
        <v-btn color="error" @click="deleteDataset">Delete Dataset</v-btn>
      </v-col>
    </v-row>

    <!-- Dataset images and toggles for filtering -->
    <v-row>
      <v-btn-toggle v-model="toggle" mandatory class="my-5">
        <v-btn value="all">All</v-btn>
        <v-btn value="annotated">Annotated</v-btn>
        <v-btn value="unannotated">Unannotated</v-btn>
      </v-btn-toggle>
    </v-row>
    <v-row>
      <v-col v-for="(image, index) in filteredImages" :key="index" cols="12" sm="6" md="3">
        <v-hover v-slot:default="{ hover }">
          <v-card :elevation="hover ? 12 : 2" @click="openImageDialog(image)">
            <v-img :src="image.src" height="200px" class="grey lighten-2">
              <v-expand-transition>
                <div v-if="hover" class="d-flex transition-fast-in-fast-out orange darken-2 white--text pa-2" style="height: 100%;">
                  <v-row align="center" justify="center">
                    {{ image.classes }}
                  </v-row>
                </div>
              </v-expand-transition>
            </v-img>
          </v-card>
        </v-hover>
      </v-col>
      <v-row v-if="filteredImages.length === 0" justify="center">
        <p>No images found or selected filter has no images.</p>
      </v-row>
    </v-row>

    <!-- Dialog for image upload -->
    <v-dialog v-model="uploadDialog" persistent max-width="600px">
      <v-card>
        <v-card-title class="headline">Upload Images</v-card-title>
        <v-card-text>
          <v-file-input
            v-model="imageFiles"
            label="Select Images"
            multiple
            accept=".png,.jpg,.jpeg"
          ></v-file-input>
          <v-file-input
            v-model="annotationFiles"
            label="Select Annotations"
            multiple
            accept=".txt"
          ></v-file-input>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="uploadDialog = false">Cancel</v-btn>
          <v-btn color="green darken-1" text @click="uploadFiles">Upload</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Dialog for image details -->
    <v-dialog v-model="imageDialog" persistent max-width="600px">
      <v-card>
        <v-card-title class="headline">Image Details</v-card-title>
        <v-card-text>
          <div>
            <img :src="selectedImage.src" alt="Selected" style="width: 100%;">
          </div>
          <p>Class: {{ selectedImage.classes }}</p>
          <p>Annotated: {{ selectedImage.annotated ? 'Yes' : 'No' }}</p>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="imageDialog = false">Close</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      images: [], // All images loaded from the server
      toggle: 'all', // Toggle state for filtering images
      selectedImage: null, // Currently selected image for details
      imageDialog: false, // Controls visibility of the image dialog
      uploadDialog: false, // Controls visibility of the upload dialog
      imageFiles: [], // Selected image files for upload
      annotationFiles: [], // Selected annotation files for upload
      lastUpdated: new Date().toLocaleString(), // Last time the dataset was fetched
    };
  },
  computed: {
    filteredImages() {
      // Filter images based on the toggle
      return this.images.filter(image => {
        if (this.toggle === 'all') return true;
        return this.toggle === 'annotated' ? image.annotated : !image.annotated;
      });
    }
  },
  methods: {
    async fetchImages() {
      try {
        const response = await axios.get('/dataset');
        this.images = response.data.image_urls.map(url => ({
          src: url,
          classes: 'Unknown', // Placeholder for classes
          annotated: false, // Placeholder for annotation status
        }));
        this.lastUpdated = new Date().toLocaleString();
      } catch (error) {
        console.error('Error fetching images:', error);
        alert('Failed to fetch images');
      }
    },
    async deleteDataset() {
      if (confirm("Are you sure you want to delete all images? This cannot be undone.")) {
        try {
          await axios.post('/delete_dataset_images');
          this.images = [];
          alert("Dataset successfully deleted.");
        } catch (error) {
          console.error('Error deleting dataset:', error);
          alert('Failed to delete dataset');
        }
      }
    },
    async uploadFiles() {
      const formData = new FormData();
      this.imageFiles.forEach(file => formData.append('images', file));
      this.annotationFiles.forEach(file => formData.append('annotations', file));

      try {
        const response = await axios.post('/uploadmulti', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
        alert(response.data.message);
        this.uploadDialog = false;
        this.fetchImages(); // Refresh the image list after upload
      } catch (error) {
        console.error('Error uploading files:', error);
        alert('Failed to upload files');
      }
    },
    openImageDialog(image) {
      this.selectedImage = image;
      this.imageDialog = true;
    }
  },
  mounted() {
    this.fetchImages(); // Initial fetch of images
  }
};
</script>

<style scoped>
.selected-class {
  color: #274C77 !important;
  border-radius: 0% !important;
  border-bottom: 4px solid #274C77 !important;
}
.notselected-class {
  color: #8B8C89;
  border-bottom: 4px solid #8B8C89;
}
</style>
