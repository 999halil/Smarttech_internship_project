<template>
    <div class="containermain">
      <h2 class="centered-heading">Model List</h2>
      <v-container>
        <v-row v-for="model in models" :key="model.id" class="mb-3">
          <v-col cols="12">
            <v-card class="model-card">
              <v-card-text>
                <v-row>
                  <v-col cols="6" class="text-left">
                    <p><strong>Epochs:</strong> {{ model.epochs }}</p>
                    <p><strong>Patience:</strong> {{ model.patience }}</p>
                    <p><strong>Batch Size:</strong> {{ model.batch_size }}</p>
                    <p><strong>Learning Rate:</strong> {{ model.learning_rate }}</p>
                  </v-col>
                  <v-col cols="6" class="text-left">
                    <p><strong>Trained at:</strong> {{ model.created_at }}</p>
                    <p><strong>Precision:</strong> {{ model.precision }}</p>
                    <p><strong>Model trained on:</strong> {{ model.classes_detected }}</p>
                    <p v-if="model.selected === 'True'"><strong>This model is currently selected</strong></p>
                  </v-col>
                </v-row>
                <v-img
                  :src="`${model.folder_name}/results.png`"
                  class="model-image"
                  @click="expandImage"
                ></v-img>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        models: [],
      };
    },
    methods: {
      async fetchModels() {
        try {
          const response = await axios.get('http://127.0.0.1:5000/models');
          this.models = response.data;
        } catch (error) {
          console.error('Error fetching models:', error);
        }
      },
      expandImage(event) {
        event.target.classList.toggle('expanded');
      },
    },
    async created() {
      await this.fetchModels();
    },
  };
  </script>
  
  <style scoped>
  .containermain {
    text-align: center;
    align-items: center;
    margin-bottom: 2%;
  }
  
  .centered-heading {
    margin-top: 2%;
    margin-bottom: 2%;
    display: inline-block;
  }
  
  .model-card {
    background-color: #f2f2f2;
    padding: 20px;
    border-radius: 10px;
  }
  
  .text-left {
    text-align: left;
  }
  
  .model-image {
    margin-top: 10px;
    max-height: 130px;
    cursor: pointer;
    transition: max-height 0.3s;
  }
  
  .model-image.expanded {
    max-height: 200px;
  }
  </style>
  