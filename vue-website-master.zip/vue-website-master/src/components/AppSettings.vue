<template>
  <div class="containermain">
    <h2 class="centered-heading">Settings</h2>
    <v-slider
      v-model="confidence"
      :min="0"
      :max="1"
      step="0.01"
      label="Confidence"
    ></v-slider>
    <span>{{ confidence.toFixed(2) }}</span>
    <v-btn color="primary" class="mt-3" @click="updateConfidence">Update Confidence</v-btn>
    <v-form @submit.prevent="submitSettings">
      <v-radio-group v-model="selectedModel" class="radio-group">
        <v-row v-for="model in models" :key="model.id" class="mb-3">
          <v-col cols="12">
            <v-card>
              <v-card-text>
                <v-radio :value="model.folder_name">
                  <template #label>
                    <div class="model-details">
                      <p><strong>Epochs:</strong> {{ model.epochs }}</p>
                      <p><strong>Precision:</strong> {{ model.precision }}</p>
                      <p><strong>Trained at:</strong> {{ model.created_at }}</p>
                      <p><strong>Model trained on:</strong> {{ model.classes_detected }}</p>
                    </div>
                  </template>
                </v-radio>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>
      </v-radio-group>
      <v-btn type="submit" color="primary" class="mt-3">Submit</v-btn>
    </v-form>
  </div>
</template>

<script>
import axios from 'axios';
import { VSlider, VRadioGroup, VRadio, VForm, VRow, VCol, VCard, VCardText, VBtn } from 'vuetify/dist/vuetify.min.css';

export default {
  components: {
    VSlider,
    VRadioGroup,
    VRadio,
    VForm,
    VRow,
    VCol,
    VCard,
    VCardText,
    VBtn
  },
  data() {
    return {
      models: [],
      selectedModel: null,
      confidence: 0.5,
    };
  },
  methods: {
    async fetchModels() {
      const response = await axios.get('http://127.0.0.1:5000/settings');
      this.models = response.data;
    },
    async submitSettings() {
  try {
    await axios.post('http://127.0.0.1:5000/settings', { model: this.selectedModel });
    alert('Settings saved successfully!');
  } catch (error) {
    console.error('Error saving settings:', error.response ? error.response.data : error.message);
    alert('Failed to save settings.');
  }
},
    fetchConfidence() {
      axios.get('http://127.0.0.1:5000/settings/confidence').then(response => {
        this.confidence = response.data.confidence;
      });
    },
    updateConfidence() {
      axios.post('http://127.0.0.1:5000/settings/confidence', { confidence: this.confidence })
        .then(response => {
          console.log('Confidence updated:', response.data);
          alert('Confidence updated successfully!');
        })
        .catch(error => {
          console.error('Error updating confidence:', error);
          alert('Failed to update confidence.');
        });
    },
  },
  created() {
    this.fetchModels();
    this.fetchConfidence();
  },
};
</script>

<style scoped>
.containermain {
  text-align: center;
  align-items: center;
  margin-bottom: 2%;
}

.centered-heading {
  margin-top: 2%;
  margin-bottom: 2%;
  display: inline-block;
}

.slider {
  max-width: 300px;
  margin: auto;
}

.model-details {
  text-align: left;
}

.radio-group {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.v-card {
  width: 100%;
}
</style>
