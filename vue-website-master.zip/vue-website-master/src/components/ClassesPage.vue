<template>
  <div>
    <v-row justify="space-between" class="mt-2">
      <v-col cols="6" class="ml-12 mt-12">
        <p class="text-h6">Classes</p>
        <p class="caption ma-1 ml-10">Last updated on 01/06/23 at 11:25</p>
      </v-col>
    </v-row>
    <v-divider :thickness="2" color="black"></v-divider>
    <v-row class="mt-3" justify="center">
      <v-col cols="2">
        <v-row>
          <v-card class="ml-5 my-3" style="background-color: white;" min-width="90%">
            <v-btn variant="text" class="text-none" min-width="100%" prepend-icon="mdi-plus-circle" @click="openAddDialog">
              Add Class
            </v-btn>
          </v-card>
        </v-row>
        <v-row>
          <v-card class="px-6 ml-5 my-3" style="background-color: white; height: 100%;" min-width="90%">
            <v-row class="pt-3">
              <p class="text-h5">Overview</p>
            </v-row>
            <v-row class="pt-3 ml-0">
              <p class="text-subtitle-2">Total Classes</p>
            </v-row>
            <v-row class="pa-1 mb-2 ml-5">
              <p class="text-body-2">{{ classCount }} Classes</p>
            </v-row>
            <v-row class="pt-1 ml-0">
              <p class="text-subtitle-2">Currently in use Classes</p>
            </v-row>
            <v-row v-for="(item, index) in classes" :key="index" class="pa-1 ml-5">
              <v-icon>mdi-rectangle</v-icon>
              <span class="text-body-2">{{ item.name }}</span>
            </v-row>
            <v-row class="mb-3"></v-row>
          </v-card>
        </v-row>
      </v-col>
      <v-col cols="10">
        <v-card class="mr-10">
          <v-row justify="center" class="text-center pt-2" style="background-color:darkgrey;">
            <v-col cols="2">
              <span>Id</span>
            </v-col>
            <v-col cols="4">
              <span>Class Name</span>
            </v-col>
            <v-col cols="4">
              <span>Actions</span>
            </v-col>
          </v-row>
          <v-row class="text-center mb-1" v-for="(item, index) in classes" :key="index">
            <v-col cols="2">
              <span>{{ item.id_class }}</span>
            </v-col>
            <v-col cols="4">
              <span>{{ item.name }}</span>
            </v-col>
            <v-col cols="4">
              <v-icon @click="openEditDialog(item)">mdi-pencil</v-icon>
              <v-icon @click="openDeleteDialog(item)">mdi-delete</v-icon>
            </v-col>
          </v-row>
        </v-card>
      </v-col>
    </v-row>

    <!-- Add Class Dialog -->
    <v-dialog v-model="addDialog" max-width="500px">
      <v-card>
        <v-card-title>
          <span class="text-h5">Add New Class</span>
        </v-card-title>
        <v-card-text>
          <v-text-field v-model="newClass.id_class" label="Class Id"></v-text-field>
          <v-text-field v-model="newClass.name" label="Class Name"></v-text-field>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue-darken-1" variant="text" @click="closeAddDialog">Cancel</v-btn>
          <v-btn color="blue-darken-1" variant="text" @click="saveNewClass">Save</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Edit Class Dialog -->
    <v-dialog v-model="editDialog" max-width="500px">
      <v-card>
        <v-card-title>
          <span class="text-h5">Edit Class</span>
        </v-card-title>
        <v-card-text>
          <v-text-field v-model="editedItem.id_class" label="Class Id"></v-text-field>
          <v-text-field v-model="editedItem.name" label="Class Name"></v-text-field>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue-darken-1" variant="text" @click="closeEditDialog">Cancel</v-btn>
          <v-btn color="blue-darken-1" variant="text" @click="saveEditedClass">Save</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Delete Class Dialog -->
    <v-dialog v-model="deleteDialog" max-width="500px">
      <v-card>
        <v-card-title>
          <span class="text-h5">Delete Class</span>
        </v-card-title>
        <v-card-text>
          Are you sure you want to delete this class?
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue-darken-1" variant="text" @click="closeDeleteDialog">Cancel</v-btn>
          <v-btn color="red" dark @click="deleteClass">Delete</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      classes: [],
      addDialog: false,
      editDialog: false,
      deleteDialog: false,
      newClass: {
        id_class: '',
        name: ''
      },
      editedItem: {
        id_class: '',
        name: ''
      },
      selectedItemIndex: -1
    };
  },
  computed: {
    classCount() {
      return this.classes.length;
    }
  },
  methods: {
    fetchClasses() {
      axios.get('http://127.0.0.1:5000/api/classes')
        .then(response => {
          this.classes = response.data;
        })
        .catch(error => {
          console.error('Error fetching classes:', error);
        });
    },
    openAddDialog() {
      this.addDialog = true;
    },
    closeAddDialog() {
      this.addDialog = false;
      this.newClass = {
        id_class: '',
        name: ''
      };
    },
    saveNewClass() {
      axios.post('http://127.0.0.1:5000/api/classes', this.newClass)
        .then(response => {
          this.classes.push(response.data);
          this.closeAddDialog();
        })
        .catch(error => {
          console.error('Error adding class:', error);
        });
    },
    openEditDialog(item) {
      this.selectedItemIndex = this.classes.indexOf(item);
      this.editedItem = { ...item };
      this.editDialog = true;
    },
    closeEditDialog() {
      this.editDialog = false;
      this.editedItem = {
        id_class: '',
        name: ''
      };
      this.selectedItemIndex = -1;
    },
    saveEditedClass() {
      axios.put(`http://127.0.0.1:5000/api/classes/${this.editedItem.id}`, this.editedItem)
        .then(response => {
          this.classes[this.selectedItemIndex] = response.data;
          this.closeEditDialog();
        })
        .catch(error => {
          console.error('Error editing class:', error);
        });
    },
    openDeleteDialog(item) {
      this.selectedItemIndex = this.classes.indexOf(item);
      this.deleteDialog = true;
    },
    closeDeleteDialog() {
      this.deleteDialog = false;
      this.selectedItemIndex = -1;
    },
    deleteClass() {
      axios.delete(`http://127.0.0.1:5000/api/classes/${this.classes[this.selectedItemIndex].id}`)
        .then(() => {
          this.classes.splice(this.selectedItemIndex, 1);
          this.closeDeleteDialog();
        })
        .catch(error => {
          console.error('Error deleting class:', error);
        });
    }
  },
  created() {
    this.fetchClasses();
  }
};
</script>

<style scoped>
.centered-heading {
  margin-top: 2%;
  margin-bottom: 2%;
  display: inline-block;
}

.containermain {
  text-align: center;
  align-items: center;
  margin-bottom: 2%;
}
</style>
